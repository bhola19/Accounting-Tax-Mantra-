
'use client';

import Link from 'next/link';

export default function ServicesHeader() {
  return (
    <section className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-700 py-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center text-white">
          <nav className="mb-8">
            <Link href="/" className="text-blue-200 hover:text-yellow-300 transition-colors cursor-pointer">
              Home
            </Link>
            <span className="mx-3 text-blue-200">/</span>
            <span className="text-yellow-300">Services</span>
          </nav>
          
          <h1 className="text-5xl font-bold mb-6">
            Our Professional Services
          </h1>
          <div className="w-24 h-1 bg-yellow-400 mx-auto mb-8"></div>
          
          <p className="text-xl text-blue-100 max-w-3xl mx-auto leading-relaxed">
            Comprehensive financial solutions tailored to meet your business needs. From taxation to business registration, we've got you covered with expert professional services.
          </p>
        </div>
      </div>
    </section>
  );
}