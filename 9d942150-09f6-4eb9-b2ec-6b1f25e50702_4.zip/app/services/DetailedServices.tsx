
'use client';

export default function DetailedServices() {
  const serviceCategories = [
    {
      icon: "ri-file-text-line",
      title: "Taxation Services",
      color: "blue",
      services: [
        { name: "Income Tax Return (ITR) Filing", detail: "For Individuals, Firms, Companies" },
        { name: "TDS Return Filing & Compliance", detail: "Complete TDS management" },
        { name: "Advance Tax Computation & Payment", detail: "Strategic tax planning" },
        { name: "GST Registration & Filing", detail: "GSTR-1, 3B, and other forms" },
        { name: "GST Refund & ITC Reconciliation", detail: "Maximize your refunds" },
        { name: "Representation before Tax Authorities", detail: "Professional advocacy" }
      ]
    },
    {
      icon: "ri-calculator-line",
      title: "Accounting & Bookkeeping",
      color: "green",
      services: [
        { name: "Monthly/Quarterly/Annual Bookkeeping", detail: "Complete record maintenance" },
        { name: "Financial Statements Preparation", detail: "Balance Sheet, P&L statements" },
        { name: "Virtual CFO Services", detail: "Strategic financial guidance" },
        { name: "Budgeting & Forecasting", detail: "Future planning and analysis" },
        { name: "Payroll Processing & Compliance", detail: "Employee compensation management" }
      ]
    },
    {
      icon: "ri-building-line",
      title: "Business Registration & Startup Services",
      color: "purple",
      services: [
        { name: "Company Registration", detail: "Pvt Ltd, LLP, OPC, Partnership" },
        { name: "MSME / Udyam Registration", detail: "Small business benefits" },
        { name: "Shop & Establishment License", detail: "Legal business operations" },
        { name: "Import Export Code (IEC)", detail: "International trade enablement" },
        { name: "Startup India Registration & Compliance", detail: "Startup benefits and support" }
      ]
    },
    {
      icon: "ri-shield-check-line",
      title: "Compliance & Legal Support",
      color: "red",
      services: [
        { name: "ROC Filings (MCA Compliance)", detail: "Ministry of Corporate Affairs" },
        { name: "Director KYC (DIR-3 KYC)", detail: "Mandatory director verification" },
        { name: "DIN & Digital Signature (DSC)", detail: "Digital identity solutions" },
        { name: "Partnership/LLP Deed Drafting", detail: "Legal document preparation" },
        { name: "Legal Notices & Agreements", detail: "Professional legal documentation" },
        { name: "Professional Tax, PF, ESI Registration", detail: "Employee benefit compliance" }
      ]
    },
    {
      icon: "ri-search-line",
      title: "Auditing & Assurance",
      color: "indigo",
      services: [
        { name: "Internal Audits", detail: "Comprehensive internal review" },
        { name: "Tax Audits under Income Tax Act", detail: "Statutory compliance audits" },
        { name: "GST Audits", detail: "GST compliance verification" },
        { name: "Statutory Audits for Companies", detail: "Annual audit requirements" },
        { name: "Audit Report Preparation", detail: "Professional audit documentation" }
      ]
    },
    {
      icon: "ri-lightbulb-line",
      title: "Advisory & Consultancy",
      color: "yellow",
      services: [
        { name: "Tax Planning & Saving Strategies", detail: "Optimize your tax burden" },
        { name: "Investment Planning & Financial Advisory", detail: "Wealth management guidance" },
        { name: "Loan & Project Report Preparation", detail: "Funding documentation support" },
        { name: "Business Valuation", detail: "Professional business assessment" },
        { name: "Succession Planning", detail: "Future business continuity" }
      ]
    }
  ];

  const specialServices = [
    { name: "PAN/TAN Application & Corrections", detail: "Tax identification services" },
    { name: "DSC Token Procurement", detail: "Digital signature certificates" },
    { name: "Response to Income Tax/GST Notices", detail: "Professional notice handling" },
    { name: "Property Registration & Capital Gain Tax Planning", detail: "Real estate tax optimization" },
    { name: "Trust & Society Registration", detail: "Non-profit organization setup" }
  ];

  const getColorClasses = (color: string) => {
    const colors = {
      blue: "bg-blue-100 text-blue-600 border-blue-200",
      green: "bg-green-100 text-green-600 border-green-200",
      purple: "bg-purple-100 text-purple-600 border-purple-200",
      red: "bg-red-100 text-red-600 border-red-200",
      indigo: "bg-indigo-100 text-indigo-600 border-indigo-200",
      yellow: "bg-yellow-100 text-yellow-600 border-yellow-200"
    };
    return colors[color as keyof typeof colors] || colors.blue;
  };

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-12">
          {serviceCategories.map((category, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 shadow-lg border border-gray-100">
              <div className="flex items-center mb-6">
                <div className={`w-12 h-12 rounded-full flex items-center justify-center mr-4 ${getColorClasses(category.color)}`}>
                  <i className={`${category.icon} text-xl`}></i>
                </div>
                <h3 className="text-2xl font-bold text-gray-900">
                  {category.title}
                </h3>
              </div>
              
              <div className="space-y-4">
                {category.services.map((service, idx) => (
                  <div key={idx} className="border-l-4 border-gray-200 pl-4 hover:border-blue-500 transition-colors">
                    <h4 className="font-semibold text-gray-900 mb-1">
                      {service.name}
                    </h4>
                    <p className="text-sm text-gray-600">
                      {service.detail}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          ))}
        </div>
        
        <div className="mt-16 bg-gradient-to-r from-blue-600 to-blue-700 rounded-2xl p-8 text-white">
          <div className="text-center mb-8">
            <h3 className="text-3xl font-bold mb-4">
              Specialized Services
            </h3>
            <p className="text-blue-100 text-lg">
              Additional expert services to meet your specific requirements
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {specialServices.map((service, index) => (
              <div key={index} className="bg-white/10 rounded-lg p-6 backdrop-blur-sm">
                <h4 className="font-semibold text-white mb-2">
                  {service.name}
                </h4>
                <p className="text-blue-100 text-sm">
                  {service.detail}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}