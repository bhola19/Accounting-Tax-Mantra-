
'use client';

import ServicesHeader from './ServicesHeader';
import DetailedServices from './DetailedServices';
import ProcessSection from './ProcessSection';
import Footer from '../../components/Footer';

export default function ServicesPage() {
  return (
    <div className="min-h-screen">
      <ServicesHeader />
      <DetailedServices />
      <ProcessSection />
      <Footer />
    </div>
  );
}