
'use client';

import Link from 'next/link';

export default function ProcessSection() {
  const steps = [
    {
      number: "01",
      title: "Initial Consultation",
      description: "Free consultation to understand your requirements and business needs"
    },
    {
      number: "02", 
      title: "Requirement Analysis",
      description: "Detailed analysis of your financial situation and compliance requirements"
    },
    {
      number: "03",
      title: "Service Planning",
      description: "Customized service plan with timeline and cost transparency"
    },
    {
      number: "04",
      title: "Documentation",
      description: "Gather all necessary documents and information for processing"
    },
    {
      number: "05",
      title: "Execution",
      description: "Professional execution of services with regular progress updates"
    },
    {
      number: "06",
      title: "Delivery & Support",
      description: "Timely delivery of completed work with ongoing support"
    }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-6">
            Our Service Process
          </h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto mb-6"></div>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We follow a systematic approach to ensure quality service delivery and complete client satisfaction
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8 mb-16">
          {steps.map((step, index) => (
            <div key={index} className="text-center group">
              <div className="relative mb-6">
                <div className="w-20 h-20 bg-blue-600 text-white rounded-full flex items-center justify-center mx-auto text-2xl font-bold group-hover:bg-blue-700 transition-colors">
                  {step.number}
                </div>
                {index < steps.length - 1 && (
                  <div className="hidden lg:block absolute top-10 left-1/2 transform translate-x-8 w-32 h-0.5 bg-gray-300"></div>
                )}
              </div>
              <h3 className="text-xl font-bold text-gray-900 mb-3">
                {step.title}
              </h3>
              <p className="text-gray-600 leading-relaxed">
                {step.description}
              </p>
            </div>
          ))}
        </div>

        <div className="text-center bg-blue-50 rounded-2xl p-12">
          <h3 className="text-3xl font-bold text-gray-900 mb-4">
            Ready to Get Started?
          </h3>
          <p className="text-lg text-gray-600 mb-8 max-w-2xl mx-auto">
            Let us help you streamline your financial operations. Contact us today for a free consultation and discover how we can support your business growth.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/contact" className="bg-blue-600 hover:bg-blue-700 text-white px-8 py-4 rounded-lg font-semibold text-lg transition-colors whitespace-nowrap cursor-pointer">
              Schedule Consultation
            </Link>
            <Link href="tel:+919643480009" className="border-2 border-blue-600 text-blue-600 hover:bg-blue-600 hover:text-white px-8 py-4 rounded-lg font-semibold text-lg transition-all whitespace-nowrap cursor-pointer">
              Call Now: +91 96434 80009
            </Link>
          </div>
        </div>
      </div>
    </section>
  );
}
