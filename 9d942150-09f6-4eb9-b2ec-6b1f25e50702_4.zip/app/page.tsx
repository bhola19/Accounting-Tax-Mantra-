
'use client';

import Hero from '../components/Hero';
import ServicesGrid from '../components/ServicesGrid';
import AboutSection from '../components/AboutSection';
import WhyChooseUs from '../components/WhyChooseUs';
import ContactSection from '../components/ContactSection';
import Footer from '../components/Footer';

export default function Home() {
  return (
    <div className="min-h-screen">
      <Hero />
      <ServicesGrid />
      <AboutSection />
      <WhyChooseUs />
      <ContactSection />
      <Footer />
    </div>
  );
}