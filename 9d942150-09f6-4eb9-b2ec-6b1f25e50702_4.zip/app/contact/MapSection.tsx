
'use client';

export default function MapSection() {
  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Find Our Office
          </h2>
          <div className="w-20 h-1 bg-blue-600 mx-auto mb-6"></div>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
            Located in the heart of Mumbai's business district, our office is easily accessible by public transport and has ample parking facilities.
          </p>
        </div>

        <div className="grid lg:grid-cols-3 gap-12 items-start">
          <div className="lg:col-span-2">
            <div className="bg-gray-100 rounded-2xl overflow-hidden shadow-lg h-96">
              <iframe
                src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3771.9856543220035!2d72.83106531490213!3d19.03316298707895!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7cf26f4b6b5ab%3A0xf4f1b4f1b4f1b4f1!2sBandra%20Kurla%20Complex%2C%20Bandra%20East%2C%20Mumbai%2C%20Maharashtra!5e0!3m2!1sen!2sin!4v1635789012345!5m2!1sen!2sin"
                width="100%"
                height="100%"
                style={{ border: 0 }}
                allowFullScreen
                loading="lazy"
                referrerPolicy="no-referrer-when-downgrade"
                title="Accounting Tax Mantra Office Location"
              ></iframe>
            </div>
          </div>

          <div className="space-y-8">
            <div className="bg-blue-50 rounded-xl p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                Office Address
              </h3>
              <div className="space-y-3 text-gray-700">
                <p className="font-medium">Accounting Tax Mantra</p>
                <p>1119, Kriti Shikhar Building</p>
                <p>District Center, Janakpuri</p>
                <p>Delhi - 110058</p>
                <p>India</p>
              </div>
            </div>

            <div className="bg-green-50 rounded-xl p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                Directions
              </h3>
              <ul className="space-y-2 text-gray-700">
                <li className="flex items-start">
                  <i className="ri-subway-line text-green-600 mr-2 mt-1"></i>
                  <span>5 min walk from Janakpuri West Metro</span>
                </li>
                <li className="flex items-start">
                  <i className="ri-bus-line text-green-600 mr-2 mt-1"></i>
                  <span>Multiple bus routes available</span>
                </li>
                <li className="flex items-start">
                  <i className="ri-car-line text-green-600 mr-2 mt-1"></i>
                  <span>Paid parking available in building</span>
                </li>
                <li className="flex items-start">
                  <i className="ri-taxi-line text-green-600 mr-2 mt-1"></i>
                  <span>Easily accessible by cab/taxi</span>
                </li>
              </ul>
            </div>

            <div className="bg-yellow-50 rounded-xl p-6">
              <h3 className="text-xl font-bold text-gray-900 mb-4">
                Important Note
              </h3>
              <p className="text-gray-700 mb-4">
                We recommend scheduling an appointment before visiting to ensure our experts are available to assist you.
              </p>
              <a 
                href="tel:+919643480009"
                className="bg-yellow-500 hover:bg-yellow-600 text-black px-4 py-2 rounded-lg font-medium transition-colors inline-block whitespace-nowrap cursor-pointer"
              >
                Call to Schedule
              </a>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
