
'use client';

import ContactHeader from './ContactHeader';
import ContactForm from './ContactForm';
import ContactInfo from './ContactInfo';
import MapSection from './MapSection';
import Footer from '../../components/Footer';

export default function ContactPage() {
  return (
    <div className="min-h-screen">
      <ContactHeader />
      <div className="grid lg:grid-cols-2">
        <ContactForm />
        <ContactInfo />
      </div>
      <MapSection />
      <Footer />
    </div>
  );
}