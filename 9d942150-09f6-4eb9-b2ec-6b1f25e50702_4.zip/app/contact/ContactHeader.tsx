
'use client';

import Link from 'next/link';

export default function ContactHeader() {
  return (
    <section className="bg-gradient-to-br from-blue-900 via-blue-800 to-blue-700 py-20">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center text-white">
          <nav className="mb-8">
            <Link href="/" className="text-blue-200 hover:text-yellow-300 transition-colors cursor-pointer">
              Home
            </Link>
            <span className="mx-3 text-blue-200">/</span>
            <span className="text-yellow-300">Contact Us</span>
          </nav>
          
          <h1 className="text-5xl font-bold mb-6">
            Get in Touch
          </h1>
          <div className="w-24 h-1 bg-yellow-400 mx-auto mb-8"></div>
          
          <p className="text-xl text-blue-100 max-w-3xl mx-auto leading-relaxed">
            Ready to transform your business finances? Contact our expert team for personalized solutions and professional guidance.
          </p>
        </div>
      </div>
    </section>
  );
}