
'use client';

export default function ContactInfo() {
  const contactMethods = [
    {
      icon: "ri-phone-line",
      title: "Call Us",
      primary: "+91 96434 80009",
      secondary: "+91 87654 32109",
      description: "Mon - Sat: 9:00 AM - 7:00 PM"
    },
    {
      icon: "ri-mail-line", 
      title: "Email Us",
      primary: "taxmantra.services19@hotmail.com",
      secondary: "support@accountingtaxmantra.com",
      description: "We'll respond within 24 hours"
    },
    {
      icon: "ri-map-pin-line",
      title: "Visit Us",
      primary: "1119, Kriti Shikhar Building",
      secondary: "District Center, Janakpuri, Delhi - 110058",
      description: "By appointment only"
    },
    {
      icon: "ri-time-line",
      title: "Business Hours",
      primary: "Monday - Saturday",
      secondary: "9:00 AM - 7:00 PM IST",
      description: "Sunday: Closed"
    }
  ];

  const officeImages = [
    {
      src: "https://readdy.ai/api/search-image?query=Modern%20professional%20accounting%20office%20interior%20with%20reception%20desk%20comfortable%20seating%20area%20and%20financial%20charts%20on%20walls%20creating%20welcoming%20business%20environment%20with%20natural%20lighting&width=300&height=200&seq=office-1&orientation=landscape",
      alt: "Office Reception"
    },
    {
      src: "https://readdy.ai/api/search-image?query=Professional%20meeting%20room%20with%20conference%20table%20chairs%20and%20presentation%20screen%20for%20client%20consultations%20in%20modern%20accounting%20office%20setting%20with%20corporate%20atmosphere&width=300&height=200&seq=office-2&orientation=landscape", 
      alt: "Meeting Room"
    },
    {
      src: "https://readdy.ai/api/search-image?query=Team%20of%20professional%20accountants%20working%20at%20desks%20with%20computers%20and%20financial%20documents%20in%20modern%20office%20environment%20showcasing%20collaborative%20workspace&width=300&height=200&seq=office-3&orientation=landscape",
      alt: "Work Area"
    }
  ];

  return (
    <section className="py-20 bg-blue-50">
      <div className="max-w-2xl mx-auto px-6">
        <div className="mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Contact Information
          </h2>
          <div className="w-20 h-1 bg-blue-600 mb-6"></div>
          <p className="text-lg text-gray-600">
            Multiple ways to reach our expert team for your accounting and tax needs.
          </p>
        </div>

        <div className="space-y-8 mb-12">
          {contactMethods.map((method, index) => (
            <div key={index} className="bg-white rounded-2xl p-6 shadow-lg border border-gray-100">
              <div className="flex items-start">
                <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mr-4 flex-shrink-0">
                  <i className={`${method.icon} text-blue-600 text-xl`}></i>
                </div>
                <div className="flex-1">
                  <h3 className="text-xl font-bold text-gray-900 mb-2">
                    {method.title}
                  </h3>
                  <div className="space-y-1 mb-2">
                    <p className="text-gray-800 font-medium">
                      {method.primary}
                    </p>
                    {method.secondary && (
                      <p className="text-gray-600">
                        {method.secondary}
                      </p>
                    )}
                  </div>
                  <p className="text-sm text-gray-500">
                    {method.description}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>

        <div className="mb-12">
          <h3 className="text-2xl font-bold text-gray-900 mb-6">
            Our Office
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {officeImages.map((image, index) => (
              <div key={index} className="rounded-lg overflow-hidden shadow-md">
                <img 
                  src={image.src}
                  alt={image.alt}
                  className="w-full h-32 object-cover object-top"
                />
              </div>
            ))}
          </div>
        </div>

        <div className="bg-gradient-to-br from-blue-600 to-blue-700 rounded-2xl p-8 text-white text-center">
          <div className="w-16 h-16 bg-yellow-400 rounded-full flex items-center justify-center mx-auto mb-4">
            <i className="ri-customer-service-2-line text-2xl text-blue-900"></i>
          </div>
          <h3 className="text-2xl font-bold mb-4">
            Need Immediate Help?
          </h3>
          <p className="text-blue-100 mb-6">
            For urgent tax matters or time-sensitive compliance issues, call us directly. Our experts are ready to assist you.
          </p>
          <a 
            href="tel:+919643480009" 
            className="bg-yellow-400 hover:bg-yellow-500 text-blue-900 px-6 py-3 rounded-lg font-semibold text-lg transition-colors inline-block whitespace-nowrap cursor-pointer"
          >
            Call Now: +91 96434 80009
          </a>
        </div>
      </div>
    </section>
  );
}
