
'use client';

export default function AboutSection() {
  const stats = [
    { number: "500+", label: "Happy Clients" },
    { number: "10+", label: "Years Experience" },
    { number: "50+", label: "Services Offered" },
    { number: "99%", label: "Client Satisfaction" }
  ];

  return (
    <section className="py-20 bg-white">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid lg:grid-cols-2 gap-16 items-center">
          <div>
            <div className="mb-8">
              <h2 className="text-4xl font-bold text-gray-900 mb-6">
                About Accounting Tax Mantra
              </h2>
              <div className="w-20 h-1 bg-blue-600 mb-6"></div>
            </div>
            
            <p className="text-lg text-gray-700 mb-6 leading-relaxed">
              At Accounting Tax Mantra, we are dedicated to providing comprehensive financial solutions that empower businesses to achieve their goals. With years of expertise in taxation, accounting, and business compliance, we serve as your trusted financial partner.
            </p>
            
            <p className="text-lg text-gray-700 mb-8 leading-relaxed">
              Our team of qualified professionals brings deep industry knowledge and commitment to excellence, ensuring that your financial affairs are managed with precision and care. We believe in building long-term relationships based on trust, transparency, and outstanding service delivery.
            </p>
            
            <div className="space-y-4 mb-8">
              <div className="flex items-center">
                <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-check-line text-white text-sm"></i>
                </div>
                <span className="text-gray-700">Expert team of qualified chartered accountants and tax professionals</span>
              </div>
              <div className="flex items-center">
                <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-check-line text-white text-sm"></i>
                </div>
                <span className="text-gray-700">Comprehensive end-to-end financial solutions under one roof</span>
              </div>
              <div className="flex items-center">
                <div className="w-6 h-6 bg-green-500 rounded-full flex items-center justify-center mr-4">
                  <i className="ri-check-line text-white text-sm"></i>
                </div>
                <span className="text-gray-700">Personalized service approach tailored to your business needs</span>
              </div>
            </div>
          </div>
          
          <div>
            <img 
              src="https://readdy.ai/api/search-image?query=Professional%20accounting%20team%20working%20together%20in%20modern%20office%20environment%20with%20financial%20documents%20charts%20and%20computers%20creating%20collaborative%20trustworthy%20business%20atmosphere%20with%20warm%20natural%20lighting%20and%20contemporary%20design%20elements&width=600&height=500&seq=about-team&orientation=landscape"
              alt="Our Professional Team"
              className="rounded-2xl shadow-xl w-full h-auto object-cover object-top"
            />
          </div>
        </div>
        
        <div className="mt-20">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center">
                <div className="text-4xl lg:text-5xl font-bold text-blue-600 mb-2">
                  {stat.number}
                </div>
                <div className="text-gray-600 font-medium">
                  {stat.label}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}