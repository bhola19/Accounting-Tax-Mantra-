
'use client';

import Link from 'next/link';

export default function Footer() {
  const currentYear = new Date().getFullYear();

  const services = [
    "Income Tax Filing",
    "GST Registration",
    "Company Registration",
    "Bookkeeping",
    "Tax Planning",
    "Audit Services"
  ];

  const quickLinks = [
    { name: "About Us", href: "/about" },
    { name: "Services", href: "/services" },
    { name: "Contact", href: "/contact" },
    { name: "Blog", href: "/blog" },
    { name: "Privacy Policy", href: "/privacy" },
    { name: "Terms of Service", href: "/terms" }
  ];

  return (
    <footer className="bg-gray-900 text-white py-16">
      <div className="max-w-7xl mx-auto px-6">
        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-12">
          <div className="col-span-1 lg:col-span-1">
            <h3 className="text-2xl font-[\'Pacifico\'] text-yellow-300 mb-6">
              Accounting Tax Mantra
            </h3>
            <p className="text-gray-300 mb-6 leading-relaxed">
              Your trusted partner for comprehensive financial solutions. We help businesses grow with expert accounting, taxation, and compliance services.
            </p>
            <div className="flex space-x-4">
              <a href="#" className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center hover:bg-blue-700 transition-colors cursor-pointer">
                <i className="ri-facebook-fill text-white"></i>
              </a>
              <a href="#" className="w-10 h-10 bg-blue-400 rounded-full flex items-center justify-center hover:bg-blue-500 transition-colors cursor-pointer">
                <i className="ri-twitter-fill text-white"></i>
              </a>
              <a href="#" className="w-10 h-10 bg-blue-700 rounded-full flex items-center justify-center hover:bg-blue-800 transition-colors cursor-pointer">
                <i className="ri-linkedin-fill text-white"></i>
              </a>
              <a href="#" className="w-10 h-10 bg-pink-600 rounded-full flex items-center justify-center hover:bg-pink-700 transition-colors cursor-pointer">
                <i className="ri-instagram-fill text-white"></i>
              </a>
            </div>
          </div>
          <div>
            <h4 className="text-xl font-semibold mb-6 text-yellow-300">Our Services</h4>
            <ul className="space-y-3">
              {services.map((service, index) => (
                <li key={index}>
                  <a href="#" className="text-gray-300 hover:text-yellow-300 transition-colors cursor-pointer">
                    {service}
                  </a>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="text-xl font-semibold mb-6 text-yellow-300">Quick Links</h4>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <Link href={link.href} className="text-gray-300 hover:text-yellow-300 transition-colors cursor-pointer">
                    {link.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>
          <div>
            <h4 className="text-xl font-semibold mb-6 text-yellow-300">Contact Info</h4>
            <div className="space-y-4">
              <div className="flex items-start">
                <i className="ri-map-pin-line text-yellow-300 mr-3 mt-1"></i>
                <span className="text-gray-300">1119, Kriti Shikhar Building, District Center, Janakpuri, Delhi - 110058</span>
              </div>
              <div className="flex items-center">
                <i className="ri-phone-line text-yellow-300 mr-3"></i>
                <span className="text-gray-300">+91 96434 80009</span>
              </div>
              <div className="flex items-center">
                <i className="ri-mail-line text-yellow-300 mr-3"></i>
                <span className="text-gray-300">taxmantra.services19@hotmail.com</span>
              </div>
              <div className="flex items-start">
                <i className="ri-time-line text-yellow-300 mr-3 mt-1"></i>
                <div className="text-gray-300">
                  <div>Mon - Sat: 9:00 AM - 7:00 PM</div>
                  <div>Sunday: Closed</div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div className="border-t border-gray-800 mt-12 pt-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <p className="text-gray-400 text-center md:text-left">
              {currentYear} Accounting Tax Mantra. All rights reserved.
            </p>
            <div className="flex space-x-6 mt-4 md:mt-0">
              <Link href="/privacy" className="text-gray-400 hover:text-yellow-300 transition-colors text-sm cursor-pointer">
                Privacy Policy
              </Link>
              <Link href="/terms" className="text-gray-400 hover:text-yellow-300 transition-colors text-sm cursor-pointer">
                Terms of Service
              </Link>
              <Link href="/sitemap" className="text-gray-400 hover:text-yellow-300 transition-colors text-sm cursor-pointer">
                Sitemap
              </Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
}
