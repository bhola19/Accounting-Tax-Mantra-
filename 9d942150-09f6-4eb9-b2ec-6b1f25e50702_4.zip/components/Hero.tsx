
'use client';

import Link from 'next/link';

export default function Hero() {
  return (
    <section 
      className="relative h-screen flex items-center justify-center bg-cover bg-center bg-no-repeat"
      style={{
        backgroundImage: `url('https://readdy.ai/api/search-image?query=Professional%20modern%20office%20environment%20with%20accounting%20documents%20financial%20charts%20and%20calculator%20on%20desk%20with%20warm%20lighting%20creating%20trustworthy%20business%20atmosphere%20clean%20minimal%20design%20with%20soft%20blue%20and%20white%20tones%20perfect%20for%20accounting%20services&width=1920&height=1080&seq=hero-main&orientation=landscape')`
      }}
    >
      <div className="absolute inset-0 bg-gradient-to-r from-blue-900/80 to-blue-800/60"></div>
      
      <div className="relative z-10 w-full max-w-6xl mx-auto px-6 text-white">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-6">
            <div className="mb-4">
              <h1 className="text-5xl lg:text-6xl font-['Pacifico'] text-yellow-300 mb-4">
                Accounting Tax Mantra
              </h1>
              <div className="w-20 h-1 bg-yellow-300"></div>
            </div>
            
            <h2 className="text-3xl lg:text-4xl font-bold leading-tight">
              Your Trusted Partner for Complete 
              <span className="text-yellow-300"> Financial Solutions</span>
            </h2>
            
            <p className="text-xl text-gray-200 leading-relaxed">
              From taxation and bookkeeping to business registration and compliance, we provide comprehensive accounting services to help your business thrive with expert guidance and professional excellence.
            </p>
            
            <div className="flex flex-col sm:flex-row gap-4 pt-6">
              <Link href="/services" className="bg-yellow-500 hover:bg-yellow-600 text-black px-8 py-4 rounded-lg font-semibold text-lg transition-all transform hover:scale-105 text-center whitespace-nowrap cursor-pointer">
                Explore Our Services
              </Link>
              <Link href="/contact" className="border-2 border-white hover:bg-white hover:text-blue-900 px-8 py-4 rounded-lg font-semibold text-lg transition-all text-center whitespace-nowrap cursor-pointer">
                Get Free Consultation
              </Link>
            </div>
          </div>
          
          <div className="hidden lg:block">
          </div>
        </div>
      </div>
    </section>
  );
}