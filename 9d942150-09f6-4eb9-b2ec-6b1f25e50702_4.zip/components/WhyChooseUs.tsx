
'use client';

export default function WhyChooseUs() {
  const benefits = [
    {
      icon: "ri-user-star-line",
      title: "Expert Professionals",
      description: "Our team consists of qualified CAs, tax experts, and financial advisors with extensive industry experience"
    },
    {
      icon: "ri-time-line",
      title: "Timely Delivery",
      description: "We understand the importance of deadlines and ensure all your filings and requirements are completed on time"
    },
    {
      icon: "ri-customer-service-line",
      title: "Personalized Service",
      description: "Every client receives dedicated attention with customized solutions tailored to their specific business needs"
    },
    {
      icon: "ri-shield-star-line",
      title: "Complete Compliance",
      description: "Stay worry-free with our comprehensive compliance management across all regulatory requirements"
    },
    {
      icon: "ri-money-rupee-circle-line",
      title: "Cost Effective",
      description: "Premium quality services at competitive rates, providing excellent value for your investment"
    },
    {
      icon: "ri-phone-line",
      title: "24/7 Support",
      description: "Round-the-clock support and consultation to address your financial queries and concerns"
    }
  ];

  return (
    <section className="py-20 bg-blue-900">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-white mb-6">
            Why Choose Accounting Tax Mantra?
          </h2>
          <p className="text-xl text-blue-100 max-w-3xl mx-auto">
            We combine professional expertise with personalized service to deliver exceptional results for your business
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {benefits.map((benefit, index) => (
            <div key={index} className="text-center group">
              <div className="w-20 h-20 bg-yellow-400 rounded-full flex items-center justify-center mx-auto mb-6 group-hover:scale-110 transition-transform duration-300">
                <i className={`${benefit.icon} text-3xl text-blue-900`}></i>
              </div>
              
              <h3 className="text-xl font-bold text-white mb-4">
                {benefit.title}
              </h3>
              
              <p className="text-blue-100 leading-relaxed">
                {benefit.description}
              </p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}