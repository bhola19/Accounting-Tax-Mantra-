
'use client';

export default function ServicesGrid() {
  const services = [
    {
      icon: "ri-file-text-line",
      title: "Taxation Services",
      description: "Complete tax solutions including ITR filing, GST compliance, and representation before authorities",
      services: ["Income Tax Return Filing", "GST Registration & Filing", "TDS Return Compliance", "Tax Planning & Consultation"]
    },
    {
      icon: "ri-calculator-line",
      title: "Accounting & Bookkeeping",
      description: "Professional bookkeeping and financial statement preparation for businesses of all sizes",
      services: ["Monthly Bookkeeping", "Financial Statements", "Virtual CFO Services", "Payroll Processing"]
    },
    {
      icon: "ri-building-line",
      title: "Business Registration",
      description: "End-to-end business setup services from company registration to compliance management",
      services: ["Company Registration", "MSME Registration", "Import Export Code", "Startup India Registration"]
    },
    {
      icon: "ri-shield-check-line",
      title: "Compliance & Legal",
      description: "Ensure your business stays compliant with all regulatory requirements and legal obligations",
      services: ["ROC Filings", "Director KYC", "Legal Agreements", "Professional Tax Filing"]
    },
    {
      icon: "ri-search-line",
      title: "Auditing & Assurance",
      description: "Comprehensive auditing services to ensure accuracy and compliance in your financial records",
      services: ["Internal Audits", "Tax Audits", "GST Audits", "Statutory Audits"]
    },
    {
      icon: "ri-lightbulb-line",
      title: "Advisory & Consultancy",
      description: "Strategic financial advice to help you make informed business decisions and optimize growth",
      services: ["Tax Planning", "Investment Advisory", "Business Valuation", "Succession Planning"]
    }
  ];

  return (
    <section className="py-20 bg-gray-50">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Comprehensive Financial Services
          </h2>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto">
            We offer a complete range of accounting, taxation, and business services designed to meet all your financial needs under one roof
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
          {services.map((service, index) => (
            <div key={index} className="bg-white rounded-2xl p-8 shadow-lg hover:shadow-xl transition-all duration-300 border border-gray-100">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mb-6">
                <i className={`${service.icon} text-2xl text-blue-600`}></i>
              </div>
              
              <h3 className="text-2xl font-bold text-gray-900 mb-4">
                {service.title}
              </h3>
              
              <p className="text-gray-600 mb-6 leading-relaxed">
                {service.description}
              </p>
              
              <ul className="space-y-3">
                {service.services.map((item, idx) => (
                  <li key={idx} className="flex items-start">
                    <div className="w-2 h-2 bg-blue-600 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                    <span className="text-gray-700">{item}</span>
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}